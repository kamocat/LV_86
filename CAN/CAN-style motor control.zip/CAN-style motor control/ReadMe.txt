This project was made give teams experience with programming in a CAN style.



These things might not be the same in the actual CAN firmware:

Every time a value is defined, it is also returned
Current mode is disabled
When both the encoder and potentiometer are configured, the encoder will be used.
Position is in thousanths of turns.
"Pot turns" refers to a potentiometer with multiple turns, not a continuous-turn pot.
"Soft limit enable" is 0 to disable, anything else to enable
Temperature and current are not measured.
Coast/Brake is not functional.
"Speed reference set" returns speed reference.
"Position reference set" returns position.



QUESTIONS:

Why is Position an I32, but the software limits are fixed point 8.8?
Is the "voltage set" supposed to have a range from -1 to 1, or from -12 to 12?
When "voltabe mode.ramp" is 0, is it effectively infinity?